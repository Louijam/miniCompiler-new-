#pragma once
// Verhindert mehrfaches Einbinden dieser Header-Datei

// Zentrale Definition fuer Object und ObjectPtr
// Alle anderen Dateien sollen Object/ObjectPtr ausschließlich aus value.hpp beziehen,
// damit es keine widersprüchlichen Typdefinitionen gibt.
#include "value.hpp"
